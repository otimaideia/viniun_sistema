// Edge Function: WhatsApp Chatbot Handler com OpenAI
// Processa mensagens recebidas e gera respostas inteligentes

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

serve(async (req) => {
  try {
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    const { tenant_id, conversation_id, message_text, from_number } = await req.json();

    console.log(`[Chatbot] Processando mensagem de ${from_number} (tenant: ${tenant_id})`);

    // 1. Buscar configuração do bot para este tenant
    const { data: botConfig, error: configError } = await supabase
      .from('mt_whatsapp_bot_config')
      .select('*')
      .eq('tenant_id', tenant_id)
      .eq('is_active', true)
      .single();

    if (configError || !botConfig) {
      console.log('[Chatbot] Bot não configurado ou inativo');
      return new Response(JSON.stringify({
        success: false,
        reason: 'bot_not_configured',
        should_transfer_to_human: true
      }), { headers: { 'Content-Type': 'application/json' } });
    }

    // 2. Verificar se deve ativar bot (horário, tentativas, etc.)
    if (!shouldActivateBot(botConfig)) {
      console.log('[Chatbot] Bot não deve ser ativado neste momento');
      return new Response(JSON.stringify({
        success: false,
        reason: 'bot_not_active_now',
        should_transfer_to_human: true
      }), { headers: { 'Content-Type': 'application/json' } });
    }

    // 3. Buscar histórico de mensagens da conversa (últimas 10)
    const { data: messageHistory } = await supabase
      .from('mt_whatsapp_messages')
      .select('id, message, from_me, created_at')
      .eq('conversation_id', conversation_id)
      .order('created_at', { ascending: false })
      .limit(10);

    // 4. Montar contexto para OpenAI
    const messages: ChatMessage[] = [
      {
        role: 'system',
        content: botConfig.system_prompt || `Você é um assistente virtual da ${botConfig.tenant?.nome_fantasia}.
Seja educado, prestativo e objetivo.
Se não souber responder algo, diga que vai transferir para um atendente humano.`
      }
    ];

    // Adicionar histórico (inverter para ordem cronológica)
    if (messageHistory) {
      messageHistory.reverse().forEach(msg => {
        messages.push({
          role: msg.from_me ? 'assistant' : 'user',
          content: msg.message
        });
      });
    }

    // Adicionar mensagem atual
    messages.push({
      role: 'user',
      content: message_text
    });

    // 5. Chamar OpenAI API
    const openaiResponse = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${botConfig.openai_api_key}`
      },
      body: JSON.stringify({
        model: botConfig.model || 'gpt-4-turbo-preview',
        messages,
        temperature: botConfig.temperature || 0.7,
        max_tokens: botConfig.max_tokens || 500
      })
    });

    if (!openaiResponse.ok) {
      console.error('[Chatbot] Erro OpenAI:', await openaiResponse.text());
      throw new Error('Erro ao chamar OpenAI');
    }

    const openaiData = await openaiResponse.json();
    const botReply = openaiData.choices[0].message.content;

    console.log(`[Chatbot] Resposta gerada: ${botReply.substring(0, 50)}...`);

    // 6. Detectar se deve transferir para humano
    const shouldTransfer = detectHandoffTriggers(message_text, botReply, botConfig);

    if (shouldTransfer) {
      console.log('[Chatbot] Handoff detectado - transferindo para humano');

      // Adicionar conversa à fila padrão
      const { data: defaultQueue } = await supabase
        .from('mt_whatsapp_queues')
        .select('id')
        .eq('tenant_id', tenant_id)
        .eq('is_default', true)
        .single();

      if (defaultQueue) {
        await supabase.rpc('add_conversation_to_queue', {
          p_conversation_id: conversation_id,
          p_queue_id: defaultQueue.id
        });
      }

      return new Response(JSON.stringify({
        success: true,
        bot_reply: botReply + '\n\n_Aguarde, vou transferir você para um atendente humano..._',
        should_transfer_to_human: true
      }), { headers: { 'Content-Type': 'application/json' } });
    }

    // 7. Atualizar métricas do bot
    await supabase
      .from('mt_whatsapp_bot_config')
      .update({
        total_interactions: (botConfig.total_interactions || 0) + 1,
        last_interaction_at: new Date().toISOString()
      })
      .eq('id', botConfig.id);

    // 8. Retornar resposta do bot
    return new Response(JSON.stringify({
      success: true,
      bot_reply: botReply,
      should_transfer_to_human: false
    }), { headers: { 'Content-Type': 'application/json' } });

  } catch (error) {
    console.error('[Chatbot] Erro:', error);

    return new Response(JSON.stringify({
      success: false,
      error: error.message,
      should_transfer_to_human: true
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
});

// Helper: Verificar se bot deve ser ativado
function shouldActivateBot(config: any): boolean {
  // Verificar horário de funcionamento
  if (config.business_hours_only) {
    const now = new Date();
    const hour = now.getHours();
    const start = parseInt(config.business_hours_start || '8');
    const end = parseInt(config.business_hours_end || '18');

    if (hour < start || hour >= end) {
      return false;
    }
  }

  return true;
}

// Helper: Detectar gatilhos de handoff (bot → humano)
function detectHandoffTriggers(userMessage: string, botReply: string, config: any): boolean {
  const userLower = userMessage.toLowerCase();
  const botLower = botReply.toLowerCase();

  // Palavras-chave do usuário pedindo atendente
  const handoffKeywords = [
    'atendente',
    'humano',
    'pessoa',
    'gerente',
    'supervisor',
    'não entendi',
    'preciso de ajuda',
    'falar com alguém'
  ];

  if (handoffKeywords.some(kw => userLower.includes(kw))) {
    return true;
  }

  // Bot não soube responder
  const uncertainPhrases = [
    'não sei',
    'não tenho certeza',
    'não consigo',
    'desculpe',
    'infelizmente'
  ];

  if (uncertainPhrases.some(phrase => botLower.includes(phrase))) {
    return true;
  }

  // Limite de interações sem resolução
  if (config.max_bot_interactions && config.total_interactions >= config.max_bot_interactions) {
    return true;
  }

  return false;
}
